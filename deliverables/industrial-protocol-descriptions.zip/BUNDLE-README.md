# Industrial protocol description bundle

Six scoped ICP-IR v1 packages, editable templates, schemas, deterministic generators and offline validators.
Complete fixture means complete wire message inside the declared profile, not all services of each standard.
See protocols/README.md for the twelve YAML entry files and actual runtime support.

From the extracted directory: install tools/requirements-protocol.txt, then run
`python3 tests/protocol/test_model_completeness.py` for independent deep structure checks.
The StateAFL source/build and BACnet server are not bundled; use the project workspace for live mutation.
Only the declared BACnet request subset currently has a C encoder.
MANIFEST.json contains SHA-256 of every bundled content file.
